package org.thiagodnf.analysis.task;

public class ClearAllGeneratedFilesGenerator {

}
