package thiagodnf.rnsgaii.util;

public class GenerateSubSpaces {

	public static void main(String[] args) {
		
		
		
	}
}
